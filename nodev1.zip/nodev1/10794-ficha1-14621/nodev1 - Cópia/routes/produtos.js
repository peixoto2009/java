// routes/produtos.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// GET todos os produtos
router.get('/', (req, res) => {
  db.query('SELECT * FROM produtos', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// GET produtos por ID
router.get('/:id', (req, res) => {
  db.query('SELECT * FROM produtos WHERE id = ?', [req.params.id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
});

// POST criar produtos
router.post('/', (req, res) => {
  const { nome } = req.body;
  db.query('INSERT INTO produtos (nome) VALUES (?, ?)', [nome], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ id: result.insertId, nome });
  });
});

// PUT atualizar produtos
router.put('/:id', (req, res) => {
  const { nome } = req.body;
  db.query('UPDATE produtos SET nome = ?, WHERE id = ?', [nome, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ id: req.params.id, nome });
  });
});

// DELETE produtos
router.delete('/:id', (req, res) => {
  db.query('DELETE FROM produtos WHERE id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ status: 'produtos removido' });
  });
});

module.exports = router;