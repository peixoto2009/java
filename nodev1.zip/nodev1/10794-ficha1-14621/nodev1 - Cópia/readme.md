como iniciar um projeto em node: node index.js

[
  {
    "id": 1,
    "nome": "dev",
    "preco": "5.00"
  }
]